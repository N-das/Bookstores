<div class="header">
            <header>
                <h2><i> bookstore.com</i></h2>
            </header>
            <nav class="navbar">
                <ul>
                    <li><a href="admin.php">home</a></li>
                    <li><a href="admin_contact.php">messages</a></li>
                    <!-- <li><a href="#">messages</a></li> -->
                    <li><a href="admin_products.php">orders</a></li>
                    <!-- <li><i class="fa-solid fa-user fa-lg" onclick="user()"></i></li>
                    <li><i class="fa-solid fa-cart-shopping fa-lg"></i></li> -->
                </ul>
            </nav>
            <!-- <a href="#"><BUtton id="btn">LOG-OUT</BUtton></a> -->
            <div id="btn">
                <i class="fa-solid fa-user fa-lg"></i>
                <i class="fa-solid fa-cart-shopping fa-lg"></i>
            </div>
        </div>